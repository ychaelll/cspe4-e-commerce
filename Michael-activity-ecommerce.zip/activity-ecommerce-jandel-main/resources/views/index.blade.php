@extends('layouts.master')

@section('page-title', 'Home Page')


@section('content')
    <h1 class="text-center">Welcome to my store</h1>

@endsection